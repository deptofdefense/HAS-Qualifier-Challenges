# Kubos Shell Protocol

This crate contains structures and functions used by the Kubos shell service and
shell client to send and receive messages using the shell protocol.