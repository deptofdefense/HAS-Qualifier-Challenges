I2C Using Rust
==============

Please refer to the |i2c-api| crate documentation for implementation details

 .. |i2c-api| raw:: html

    <a href="../../../../rust-docs/rust_i2c/index.html" target="_blank">Rust I2C API</a>
