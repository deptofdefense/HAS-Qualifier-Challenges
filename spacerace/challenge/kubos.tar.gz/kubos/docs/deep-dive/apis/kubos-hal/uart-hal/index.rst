UART HAL
========

.. toctree::
    :caption: UART Integration
    :maxdepth: 1
    
    Using Rust <rust-uart>
