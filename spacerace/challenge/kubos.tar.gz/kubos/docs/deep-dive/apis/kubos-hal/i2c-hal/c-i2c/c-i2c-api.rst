C I2C API
---------

.. doxygenfile:: i2c.h
   :project: kubos-hal