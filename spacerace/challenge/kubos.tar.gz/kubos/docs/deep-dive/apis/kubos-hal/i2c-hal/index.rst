I2C HALs
========

.. toctree::
    :caption: I2C Integration
    :maxdepth: 1
    
    Using C <c-i2c/c-i2c>
    Using Python <python-i2c>
    Using Rust <rust-i2c>
