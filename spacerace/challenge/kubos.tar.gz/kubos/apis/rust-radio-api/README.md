# Common Radio API

This crate contains high level types and functions for use by other crates
implementing radio APIs.