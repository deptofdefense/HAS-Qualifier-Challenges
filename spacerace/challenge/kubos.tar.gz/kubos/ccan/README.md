# C-Based JSON Parser

C library for parsing and constructing JSON