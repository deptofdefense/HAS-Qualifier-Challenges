# Rust+C Build Tool

This library allows Cargo to build Rust crates which also use C APIs.

It should be included in the Rust crate's `Cargo.toml` file under the
`build-dependencies` section.