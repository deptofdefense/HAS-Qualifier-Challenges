# Copyright 2019 Kubos Corporation
# Licensed under the Apache License, Version 2.0
# See LICENSE file for details.

# This module exists to test that the app service supports multi-file applications

def test_func():
    
    print("I'm a test function")