# Shell Service

The shell service is used to provide shell access and commanding from mission
operations to the OBC.
It may also be used between a developer’s system and the OBC when in a development or
testing environment.

More information about the shell service architecture and how to use it can
be found in our [official documentation](https://docs.kubos.com/latest/ecosystem/services/shell.html)