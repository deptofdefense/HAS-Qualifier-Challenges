# Telemetry Database Service

Kubos Service for interacting with the telemetry database

More information about the telemetry database service architecture and how to use it
can be found in our [official documentation](https://docs.kubos.com/latest/ecosystem/services/telemetry-db.html)