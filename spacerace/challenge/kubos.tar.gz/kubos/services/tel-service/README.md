# Another Telemetry Service for Games

Connects to the same telemetry db, but on port 8120. Players can access this to modify telemetry db seperately from the telemetry service port that other services (e.g. hardware services) use.