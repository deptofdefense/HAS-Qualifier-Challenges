# Kubos File Transfer Service

The file transfer service is used to transfer files between the mission operations
center and the OBC.
It may also be used to transfer files between a developer’s system and the OBC when
in a development environment.

More information about the file transfer service architecture and how to use it can
be found in our [official documentation](https://docs.kubos.com/latest/ecosystem/services/file.html)