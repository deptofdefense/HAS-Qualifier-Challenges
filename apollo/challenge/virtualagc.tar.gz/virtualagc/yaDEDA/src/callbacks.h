#include <gtk/gtk.h>


void
on_KeyEntr_pressed                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_KeyEntr_released                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_KeyReadOut_pressed                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_KeyReadOut_released                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_KeyClr_pressed                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_KeyClr_released                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_Key9_pressed                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Key9_released                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Key6_pressed                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Key6_released                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Key3_pressed                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Key3_released                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Key8_pressed                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Key8_released                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Key5_pressed                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Key5_released                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Key2_pressed                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Key2_released                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Key7_pressed                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Key7_released                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Key4_pressed                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Key4_released                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Key1_pressed                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Key1_released                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_KeyPlus_pressed                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_KeyPlus_released                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_KeyMinus_pressed                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_KeyMinus_released                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_Key0_pressed                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Key0_released                       (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_MainWindow_delete_event             (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_KeyHold_pressed                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_KeyHold_released                    (GtkButton       *button,
                                        gpointer         user_data);
