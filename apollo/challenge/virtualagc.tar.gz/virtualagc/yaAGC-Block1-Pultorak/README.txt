This directory contains code derived from John Pultorak's AGC Block 1 simulator, version 1.15.

The *first* commit of it is John's unmodified code, which is intended to be built with 
Microsoft Visual C++ 6.0.

Subsequent commits represent a transformation to using GNU g++ to build it instead.

