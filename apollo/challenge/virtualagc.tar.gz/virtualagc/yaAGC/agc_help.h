#ifndef AGC_HELP_H
#define AGC_HELP_H

extern int GdbmiHelp(char* s);
extern int legacyHelp(char* s);

#endif
