[<img src="https://virtualagc.github.io/virtualagc/small-docSearchButton.png">](https://virtualagc.github.io/virtualagc/wikiSearch.html)

This is a test file.

INTPRET is the entry point to the Interpreter.
