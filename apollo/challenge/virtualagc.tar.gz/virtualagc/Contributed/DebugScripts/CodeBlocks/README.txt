Code::Blocks is the first fully documented IDE to work with the patched yaAGC not the first one operational.

Enjoy the code of 1965 in todays programming and debugging tools.
