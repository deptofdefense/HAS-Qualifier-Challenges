#!/bin/bash
# This function is only for testing purposes.  It allows me to run a task
# whose name includes the string "vncserverui" without actually having to
# install, configure, or log into vncserver remotely.

read
